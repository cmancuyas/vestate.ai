export default function UnauthorizedPage() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <h1 className="text-xl text-red-600 font-semibold">403 - Access Denied</h1>
    </div>
  )
}