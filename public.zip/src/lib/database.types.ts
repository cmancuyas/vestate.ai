// src/lib/database.types.ts
export type Database = any
