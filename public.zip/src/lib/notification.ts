'use client'
export function notifyUser(message: string) {
  // This is where you'd trigger OneSignal, email, or other notification system
  console.log('🔔 Notification:', message)
}
